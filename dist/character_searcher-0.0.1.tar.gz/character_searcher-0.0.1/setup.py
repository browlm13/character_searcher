from setuptools import setup

setup(
    name='character_searcher',
    version='0.0.1',
    packages=['character_searcher'],
    url='https://github.com/browlm13/character_searcher.git',
    author='L.J. Brown',
    description='', install_requires=['pycedict', 'pandas']
)